#ifndef __RTC__H
#define __RTC__H

void RTC_init(void);
void RTC_reset(void);
int RTC_leer_segundos(void);
int RTC_leer_minutos(void);

#endif
