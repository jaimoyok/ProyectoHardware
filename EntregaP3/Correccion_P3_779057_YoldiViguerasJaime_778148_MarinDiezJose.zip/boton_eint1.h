#ifndef __BOTON_EINT1__H
#define __BOTON_EINT1__H

#include <stdint.h>

void eint1_init (void);
void eint1_clear_nueva_pulsacion(void);
int8_t eint1_esta_pulsado(void);


#endif
