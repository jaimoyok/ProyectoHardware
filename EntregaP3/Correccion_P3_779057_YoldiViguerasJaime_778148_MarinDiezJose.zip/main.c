#include "reversi8.h"            
#include "Eventos.h"

int main(void){ 	
	iniciarOIreversi();
	gestionar_eventos();
	return 0;
}
