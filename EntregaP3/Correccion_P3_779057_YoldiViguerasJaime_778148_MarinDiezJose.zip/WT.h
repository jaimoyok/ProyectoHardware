#ifndef __WT__H
#define __WT__H

void WT_init(int sec);
void feed_WT(void);

#endif
