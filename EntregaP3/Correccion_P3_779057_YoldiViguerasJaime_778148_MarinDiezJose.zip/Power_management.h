#ifndef __POWER_MANAGEMENT__H
#define __POWER_MANAGEMENT__H

void PM_power_down(void);
void PM_idle(void);
extern void Switch_to_PLL(void);

#endif
